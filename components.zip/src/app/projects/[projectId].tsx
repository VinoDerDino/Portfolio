import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function ProjectPage() {
  const router = useRouter();
  const { projectId } = router.query;
  const [htmlContent, setHtmlContent] = useState("");
  const [subPage, setSubPage] = useState("index.html");

  useEffect(() => {
    if (projectId) {
      fetch(`/projects/${projectId}/${subPage}`)
        .then((res) => res.text())
        .then((html) => setHtmlContent(html));
    }
  }, [projectId, subPage]);

  return (
    <div>
      <h1>Projekt: {projectId}</h1>
      <nav>
        <button onClick={() => setSubPage("index.html")}>Hauptseite</button>
      </nav>
      <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
    </div>
  );
}
