import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Link from "next/link";

const geistSans = Geist({
	variable: "--font-geist-sans",
	subsets: ["latin"],
});

const geistMono = Geist_Mono({
	variable: "--font-geist-mono",
	subsets: ["latin"],
});

export const metadata: Metadata = {
	title: "VinoDerDino Portfolio",
};

export default function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	return (
		<html lang="en">
			<body
				className={`${geistSans.variable} ${geistMono.variable} antialiased`}
			>
				<nav className="fixed top-0 left-0 right-0 flex justify-center items-center gap-16 w-full h-15 bg-inherit border-b border-gray-700 z-50">
					<Link
						className="text-stone-200 font-bold hover:text-amber-700 transition duration-500"
						href="/"
					>
						<p>Home</p>
					</Link>

					<Link
						className="text-stone-200 font-bold hover:text-amber-700 transition duration-500"
						href="/projects"
					>
						<p>Projects</p>
					</Link>

					<Link
						className="text-stone-200 font-bold hover:text-amber-700 transition duration-500"
						href="/contact"
					>
						<p>Contact</p>
					</Link>
				</nav>
				<section>{children}</section>
			</body>
		</html>
	);
}
 